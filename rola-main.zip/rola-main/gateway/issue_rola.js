import pkg from '@stellar/stellar-sdk';
const { Keypair, Asset, Networks, Horizon, TransactionBuilder, Operation } = pkg;

const server = new Horizon.Server('https://horizon-testnet.stellar.org');

async function fundAccount(publicKey) {
  console.log(`Funding account ${publicKey} with Friendbot...`);
  const response = await fetch(`https://friendbot.stellar.org?addr=${encodeURIComponent(publicKey)}`);
  if (!response.ok) {
    throw new Error(`Friendbot funding failed: ${response.statusText}`);
  }
  console.log(`Account ${publicKey} funded successfully.`);
}

async function run() {
  // Generate keypairs for Issuer and Distributor
  const issuerKeys = Keypair.random();
  const distributorKeys = Keypair.random();

  console.log('--- ROLA Token Keys Generated ---');
  console.log('Issuer Public Key:     ', issuerKeys.publicKey());
  console.log('Issuer Secret Key:     ', issuerKeys.secret());
  console.log('Distributor Public Key:', distributorKeys.publicKey());
  console.log('Distributor Secret Key:', distributorKeys.secret());
  console.log('---------------------------------\n');

  // Fund both accounts on testnet
  await fundAccount(issuerKeys.publicKey());
  await fundAccount(distributorKeys.publicKey());

  // Wait a moment for Horizon to register the ledger updates
  console.log('Waiting for ledger confirmation...');
  await new Promise((resolve) => setTimeout(resolve, 5000));

  // Load distributor details
  const distributorAccount = await server.loadAccount(distributorKeys.publicKey());

  // Define ROLA asset
  const ROLA = new Asset('ROLA', issuerKeys.publicKey());

  // 1. Establish Trustline
  console.log('\nStep 1: Establishing Trustline from Distributor to Issuer for ROLA...');
  const trustTx = new TransactionBuilder(distributorAccount, {
    fee: '100000',
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: ROLA }))
    .setTimeout(30)
    .build();

  trustTx.sign(distributorKeys);
  const trustResult = await server.submitTransaction(trustTx);
  console.log('Trustline established! Tx Hash:', trustResult.hash);

  // 2. Issue/Mint the tokens (55,000 ROLA representing a 55kW solar plant capacity)
  const issuerAccount = await server.loadAccount(issuerKeys.publicKey());
  console.log('\nStep 2: Minting 55,000 ROLA from Issuer to Distributor...');
  const mintTx = new TransactionBuilder(issuerAccount, {
    fee: '100000',
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.payment({
      destination: distributorKeys.publicKey(),
      asset: ROLA,
      amount: '55000'
    }))
    .setTimeout(30)
    .build();

  mintTx.sign(issuerKeys);
  const mintResult = await server.submitTransaction(mintTx);
  console.log('Minting transaction successful! Tx Hash:', mintResult.hash);

  // 3. Compute Stellar Asset Contract (SAC) address for Soroban integration
  const sacContractId = ROLA.isNative() 
    ? 'native' 
    : ROLA.contractId(Networks.TESTNET);

  console.log('\n--- ROLA Asset Minting Complete ---');
  console.log('Asset Code:             ROLA');
  console.log('Total Supply Issued:    55,000 (1 Token = 1 Watt of 55kW PPA)');
  console.log('Stellar Asset Contract: ', sacContractId);
  console.log('Soroban Wrapper (SAC):  Use this Contract ID to interface with ROLA in Soroban smart contracts.');
  console.log('-----------------------------------\n');
}

run().catch((err) => {
  console.error('Error issuing ROLA asset:', err);
});
