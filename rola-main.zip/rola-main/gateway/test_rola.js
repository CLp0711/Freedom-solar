import pkg from '@stellar/stellar-sdk';
const { Horizon, Asset } = pkg;

const server = new Horizon.Server('https://horizon-testnet.stellar.org');

// The public keys from our live deployment
const ISSUER_PUBLIC_KEY = 'GAOSAG76RTPXEWJM2OZSVFTQRAL4AY5DGM56GX2HKLOBV2AVU3FWGMJS';
const DISTRIBUTOR_PUBLIC_KEY = 'GAKOWWKXKZEYRC4SHX7IFHLMVPEXLXTSTN4LCQH5MGRDPAKMQPQQUIZS';

async function runTests() {
  console.log('==================================================');
  console.log('       RUNNING LIVE STELLAR TESTNET VERIFICATION   ');
  console.log('==================================================\n');

  let testsPassed = 0;
  let totalTests = 0;

  function assert(condition, message) {
    totalTests++;
    if (condition) {
      testsPassed++;
      console.log(`✅ [PASS] ${message}`);
    } else {
      console.error(`❌ [FAIL] ${message}`);
    }
  }

  try {
    // Test 1: Fetch and verify issuer account
    console.log('Fetching issuer account details...');
    const issuerAccount = await server.loadAccount(ISSUER_PUBLIC_KEY);
    assert(issuerAccount.accountId() === ISSUER_PUBLIC_KEY, 'Issuer account exists on Horizon testnet.');

    // Test 2: Fetch and verify distributor account
    console.log('Fetching distributor account details...');
    const distributorAccount = await server.loadAccount(DISTRIBUTOR_PUBLIC_KEY);
    assert(distributorAccount.accountId() === DISTRIBUTOR_PUBLIC_KEY, 'Distributor account exists on Horizon testnet.');

    // Test 3: Check ROLA Trustline and Balance
    console.log('Verifying ROLA trustline and minted balance on Distributor...');
    const rolaBalanceEntry = distributorAccount.balances.find(
      (balance) => balance.asset_code === 'ROLA' && balance.asset_issuer === ISSUER_PUBLIC_KEY
    );

    assert(!!rolaBalanceEntry, 'Distributor has established a trustline for ROLA asset.');
    
    if (rolaBalanceEntry) {
      const balanceAmount = parseFloat(rolaBalanceEntry.balance);
      assert(balanceAmount === 55000, `Minted supply is correct. Expected: 55000.0000000, Actual: ${rolaBalanceEntry.balance}`);
    }

    // Test 4: Verify Soroban SAC Wrapper Derivation
    console.log('Checking Soroban Stellar Asset Contract (SAC) derivation...');
    const ROLA = new Asset('ROLA', ISSUER_PUBLIC_KEY);
    const sacContractId = ROLA.contractId('Test SDF Network ; September 2015');
    assert(
      sacContractId === 'CAZDQ34M7PMXAHU2XME3ANIQTZJ76MUIS572WZSM4XXCYWOSF2VIHQIB',
      `Soroban contract address is derived correctly. Derived: ${sacContractId}`
    );

    // Final report
    console.log('\n==================================================');
    console.log(` VERIFICATION COMPLETE: Passed ${testsPassed}/${totalTests} tests.`);
    console.log('==================================================');

    if (testsPassed !== totalTests) {
      process.exit(1);
    }
  } catch (err) {
    console.error('\n❌ Verification failed due to an unexpected error:', err.message);
    process.exit(1);
  }
}

runTests();
