/**
 * Ryowa Labs - On-Chain KYC Compliance Battle Test
 * 
 * This script runs a fully automated, safe simulation of Stellar's native
 * KYC/AML trustline authorization flags on the Testnet.
 * 
 * 1. Mints a mock asset (ROLA_SEC) with AUTHORIZATION_REQUIRED turned on.
 * 2. Creates a mock investor wallet.
 * 3. Investor opens a trustline (which is initially blocked/unauthorized).
 * 4. Tries to send ROLA_SEC to the investor -> EXPECTED FAILURE (op_src_not_authorized).
 * 5. Submits mock KYC data (fake ID, no real info exposed).
 * 6. Issuer authorizes the investor's trustline.
 * 7. Retries the payment -> SUCCESS!
 */

import pkg from "@stellar/stellar-sdk";
const { Keypair, Asset, Horizon, TransactionBuilder, Networks, Operation } = pkg;

const server = new Horizon.Server("https://horizon-testnet.stellar.org");

async function fundAccount(keypair) {
  const response = await fetch(`https://friendbot.stellar.org?addr=${keypair.publicKey()}`);
  if (!response.ok) throw new Error(`Funding failed for ${keypair.publicKey()}`);
  console.log(`   Funded: ${keypair.publicKey().slice(0, 8)}...`);
  await new Promise((resolve) => setTimeout(resolve, 3000));
}

async function runKycTest() {
  console.log("🚀 Starting On-Chain KYC Compliance Test on Stellar Testnet...\n");

  // 1. Generate Test Keypairs
  const issuer = Keypair.random();
  const distributor = Keypair.random();
  const investor = Keypair.random();

  // 2. Fund accounts via Friendbot
  console.log("💸 Funding test accounts (Free Testnet XLM)...");
  await fundAccount(issuer);
  await fundAccount(distributor);
  await fundAccount(investor);
  console.log("✅ Accounts funded.\n");

  const assetCode = "ROLASEC";
  const rolaSec = new Asset(assetCode, issuer.publicKey());

  // 3. Enable Authorization Required on the Issuer Account
  // This turns on native Stellar KYC rules for ROLASEC
  console.log("🔒 Locking Issuer account: Enabling Authorization Required...");
  const issuerAccount = await server.loadAccount(issuer.publicKey());
  const setFlagsTx = new TransactionBuilder(issuerAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.setOptions({
        setFlags: pkg.xdr.AccountFlags.authRequiredFlag().value | pkg.xdr.AccountFlags.authRevocableFlag().value
      })
    )
    .setTimeout(30)
    .build();

  setFlagsTx.sign(issuer);
  await server.submitTransaction(setFlagsTx);
  console.log("✅ Authorization Required & Revocable flags are now active.\n");

  // 4. Investor opens trustline (starts as pending/unauthorized)
  console.log("📥 Investor opens trustline for ROLASEC...");
  const investorAccount = await server.loadAccount(investor.publicKey());
  const trustTx = new TransactionBuilder(investorAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: rolaSec }))
    .setTimeout(30)
    .build();
  trustTx.sign(investor);
  await server.submitTransaction(trustTx);
  console.log("✅ Trustline opened. (Current state: UNAUTHORIZED)\n");

  // 5. Try to send tokens to investor (Expected to FAIL)
  console.log("❌ Attempting to mint tokens to unauthorized investor...");
  const distAccount = await server.loadAccount(distributor.publicKey());
  const failTx = new TransactionBuilder(distAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.payment({
        destination: investor.publicKey(),
        asset: rolaSec,
        amount: "100.0000000",
        source: issuer.publicKey()
      })
    )
    .setTimeout(30)
    .build();
  failTx.sign(distributor, issuer);

  try {
    await server.submitTransaction(failTx);
    console.log("⚠️ ERROR: Payment succeeded but should have failed!");
  } catch (error) {
    console.log("✅ SUCCESS: Transaction failed as expected!");
    // Log the result code showing that the destination trustline was not authorized
    const codes = error.response?.data?.extras?.result_codes;
    console.log("   Stellar Error Code:", JSON.stringify(codes)); // Expecting op_src_not_authorized or similar
  }

  // 6. Submit Mock KYC Compliance Data (NO sensitive data exposed)
  console.log("\n📝 Submitting Mock KYC Details to Ryowa Compliance Backend:");
  const mockKycData = {
    fullName: "Jane Doe Test",
    nationality: "Kenya",
    documentType: "Mock Passport",
    documentId: "MOCK-9999-5555",
    verificationStatus: "APPROVED"
  };
  console.log(JSON.stringify(mockKycData, null, 2));

  // 7. Authorize Investor's trustline on-chain
  console.log("\n🔑 Ryowa Labs Admin signs KYC Authorization...");
  const authAccount = await server.loadAccount(issuer.publicKey());
  const authTx = new TransactionBuilder(authAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.setTrustLineFlags({
        trustor: investor.publicKey(),
        asset: rolaSec,
        flags: { authorized: true } // Authorize!
      })
    )
    .setTimeout(30)
    .build();
  authTx.sign(issuer);
  const authResult = await server.submitTransaction(authTx);
  console.log(`✅ On-chain KYC flag set to AUTHORIZED! Hash: ${authResult.hash}\n`);

  // 8. Retry Payment (Expected to SUCCEED)
  console.log("💸 Retrying mint/payment to authorized investor...");
  const retryAccount = await server.loadAccount(distributor.publicKey());
  const successTx = new TransactionBuilder(retryAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.payment({
        destination: investor.publicKey(),
        asset: rolaSec,
        amount: "100.0000000",
        source: issuer.publicKey()
      })
    )
    .setTimeout(30)
    .build();
  successTx.sign(distributor, issuer);
  const successResult = await server.submitTransaction(successTx);
  console.log(`✅ SUCCESS! Tokens minted to investor. Hash: ${successResult.hash}\n`);

  // 9. Verify Balance
  const finalInvestorInfo = await server.loadAccount(investor.publicKey());
  const balance = finalInvestorInfo.balances.find(b => b.asset_code === "ROLASEC");
  console.log(`📊 Investor Balance: ${balance.balance} ROLASEC`);
  console.log(`🔗 Stellar.Expert: https://stellar.expert/explorer/testnet/tx/${successResult.hash}`);
}

runKycTest().catch(console.error);
