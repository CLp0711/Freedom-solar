/**
 * Ryowa Labs - ROLA / USDC Automated Market Maker (AMM) Battle Test
 * 
 * This script runs a live, end-to-end simulation of the core tokenomics cycle 
 * directly on the Stellar Testnet:
 * 
 * 1. Generates keypairs for Mock ROLA and Mock USDC stablecoins.
 * 2. Funds accounts via the testnet Friendbot and establishes trustlines.
 * 3. Mints token supplies (100,000 ROLA representing capacity, 100,000 USDC representing fiat).
 * 4. Seeds a native Stellar Liquidity Pool (AMM) for ROLA/USDC with 10,000 tokens each.
 * 5. Simulates an investor swapping 100 USDC for ROLA via the AMM.
 * 6. Asserts on-chain balance changes and outputs Stellar.Expert explorer links.
 */

import pkg from "@stellar/stellar-sdk";
const { Keypair, Asset, Horizon, TransactionBuilder, Networks, Operation, LiquidityPoolAsset, getLiquidityPoolId } = pkg;

const server = new Horizon.Server("https://horizon-testnet.stellar.org");

// Helper: Fund a keypair using Friendbot
async function fundAccount(keypair) {
  const url = `https://friendbot.stellar.org?addr=${keypair.publicKey()}`;
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Friendbot funding failed for ${keypair.publicKey()}`);
  }
  console.log(`Funded account: ${keypair.publicKey()}`);
  // Wait a brief moment for ledger confirmation
  await new Promise((resolve) => setTimeout(resolve, 3000));
}

async function runBattleTest() {
  console.log("🚀 Starting ROLA/USDC AMM Battle Test on Stellar Testnet...\n");

  // 1. Generate Keypairs
  const rolaIssuer = Keypair.random();
  const rolaDistributor = Keypair.random();
  const usdcIssuer = Keypair.random();
  const usdcDistributor = Keypair.random();
  const investor = Keypair.random();

  console.log("🔑 Generated fresh testnet keypairs:");
  console.log(`   ROLA Issuer:      ${rolaIssuer.publicKey()}`);
  console.log(`   ROLA Distributor: ${rolaDistributor.publicKey()}`);
  console.log(`   USDC Issuer:      ${usdcIssuer.publicKey()}`);
  console.log(`   USDC Distributor: ${usdcDistributor.publicKey()}`);
  console.log(`   Investor:         ${investor.publicKey()}\n`);

  // 2. Fund all accounts via Friendbot
  console.log("💸 Funding accounts via Friendbot...");
  await fundAccount(rolaIssuer);
  await fundAccount(rolaDistributor);
  await fundAccount(usdcIssuer);
  await fundAccount(usdcDistributor);
  await fundAccount(investor);
  console.log("✅ All accounts funded.\n");

  // Define Asset objects
  const rolaAsset = new Asset("ROLA", rolaIssuer.publicKey());
  const usdcAsset = new Asset("USDC", usdcIssuer.publicKey());

  // 3. Establish Trustlines & Mint Assets
  console.log("⚙️ Setting up trustlines and minting asset supplies...");

  // We load the accounts to get sequence numbers
  const rolaDistAccount = await server.loadAccount(rolaDistributor.publicKey());
  const usdcDistAccount = await server.loadAccount(usdcDistributor.publicKey());

  // ROLA Trust & Mint Transaction
  const rolaTx = new TransactionBuilder(rolaDistAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: rolaAsset })) // Open ROLA trustline
    .addOperation(
      Operation.payment({
        destination: rolaDistributor.publicKey(),
        asset: rolaAsset,
        amount: "100000.0000000", // Mint 100,000 ROLA
        source: rolaIssuer.publicKey()
      })
    )
    .setTimeout(30)
    .build();

  rolaTx.sign(rolaDistributor, rolaIssuer);
  const rolaTxResult = await server.submitTransaction(rolaTx);
  console.log(`🔹 ROLA Mint Transaction Hash: ${rolaTxResult.hash}`);

  // USDC Trust & Mint Transaction
  const usdcTx = new TransactionBuilder(usdcDistAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: usdcAsset })) // Open USDC trustline
    .addOperation(
      Operation.payment({
        destination: usdcDistributor.publicKey(),
        asset: usdcAsset,
        amount: "100000.0000000", // Mint 100,000 USDC
        source: usdcIssuer.publicKey()
      })
    )
    .setTimeout(30)
    .build();

  usdcTx.sign(usdcDistributor, usdcIssuer);
  const usdcTxResult = await server.submitTransaction(usdcTx);
  console.log(`🔹 USDC Mint Transaction Hash: ${usdcTxResult.hash}\n`);

  // 4. Seed the AMM Liquidity Pool
  console.log("🌊 Seeding the ROLA/USDC Liquidity Pool...");
  
  // To seed a native Stellar pool, the depositor must:
  // a. Establish a trustline to the pool shares asset.
  // b. Perform a LiquidityPoolDeposit.
  const poolAssets = [rolaAsset, usdcAsset];
  
  // Sort the assets alphabetically (required by Stellar protocol)
  poolAssets.sort(Asset.compare);
  
  const poolAsset = new LiquidityPoolAsset(poolAssets[0], poolAssets[1], 30);
  const poolIdHex = getLiquidityPoolId("constant_product", {
    assetA: poolAssets[0],
    assetB: poolAssets[1],
    fee: 30
  }).toString("hex");

  const changeTrustOp = Operation.changeTrust({
    asset: poolAsset
  });

  const depositOp = Operation.liquidityPoolDeposit({
    liquidityPoolId: poolIdHex,
    maxAmountA: "10000.0000000", // 10,000 of Asset A
    maxAmountB: "10000.0000000", // 10,000 of Asset B
    minPrice: "0.99",
    maxPrice: "1.01"
  });

  // We will perform these operations using the rolaDistributor account
  // but first we need to make sure rolaDistributor also has a trustline to USDC
  // and usdcDistributor sends 10,000 USDC to rolaDistributor.
  console.log("   Transferring USDC buffer to ROLA distributor to enable AMM seeding...");
  
  const setupDistAccount = await server.loadAccount(rolaDistributor.publicKey());
  const distSetupTx = new TransactionBuilder(setupDistAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: usdcAsset }))
    .setTimeout(30)
    .build();
  distSetupTx.sign(rolaDistributor);
  await server.submitTransaction(distSetupTx);

  const transferAccount = await server.loadAccount(usdcDistributor.publicKey());
  const transferTx = new TransactionBuilder(transferAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.payment({
        destination: rolaDistributor.publicKey(),
        asset: usdcAsset,
        amount: "15000.0000000" // Send 15k USDC
      })
    )
    .setTimeout(30)
    .build();
  transferTx.sign(usdcDistributor);
  await server.submitTransaction(transferTx);

  // Now submit AMM seeding
  const seedAccount = await server.loadAccount(rolaDistributor.publicKey());
  const seedTx = new TransactionBuilder(seedAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(changeTrustOp)
    .addOperation(depositOp)
    .setTimeout(30)
    .build();

  seedTx.sign(rolaDistributor);
  const seedResult = await server.submitTransaction(seedTx);
  console.log(`✅ AMM Pool Seeded successfully! Hash: ${seedResult.hash}\n`);

  // 5. Simulate Investor Buyback Swap
  console.log("💸 Simulating Investor Buyback Swap (100 USDC -> ROLA)...");

  // Setup investor trustlines first
  const investorAccount = await server.loadAccount(investor.publicKey());
  const investorSetupTx = new TransactionBuilder(investorAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(Operation.changeTrust({ asset: rolaAsset }))
    .addOperation(Operation.changeTrust({ asset: usdcAsset }))
    .setTimeout(30)
    .build();
  investorSetupTx.sign(investor);
  await server.submitTransaction(investorSetupTx);

  // Give investor some USDC now that trustline is open
  const sendUsdcAccount = await server.loadAccount(usdcDistributor.publicKey());
  const sendUsdcTx = new TransactionBuilder(sendUsdcAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.payment({
        destination: investor.publicKey(),
        asset: usdcAsset,
        amount: "500.0000000"
      })
    )
    .setTimeout(30)
    .build();
  sendUsdcTx.sign(usdcDistributor);
  await server.submitTransaction(sendUsdcTx);

  // Perform Swap: Path Payment Strict Send (Send exactly 100 USDC, get at least 90 ROLA)
  const swapAccount = await server.loadAccount(investor.publicKey());
  const swapTx = new TransactionBuilder(swapAccount, {
    fee: "10000",
    networkPassphrase: Networks.TESTNET
  })
    .addOperation(
      Operation.pathPaymentStrictSend({
        sendAsset: usdcAsset,
        sendAmount: "100.0000000",
        destination: investor.publicKey(),
        destAsset: rolaAsset,
        destMin: "90.0000000", // Accept slippage
        path: [] // Direct swap through AMM
      })
    )
    .setTimeout(30)
    .build();

  swapTx.sign(investor);
  const swapResult = await server.submitTransaction(swapTx);
  console.log(`✅ Swap completed! Hash: ${swapResult.hash}\n`);

  // 6. Verify and Log Balances
  const finalInvestorInfo = await server.loadAccount(investor.publicKey());
  console.log("📊 Final Investor Balances:");
  finalInvestorInfo.balances.forEach((b) => {
    if (b.asset_code) {
      console.log(`   ${b.asset_code}: ${b.balance}`);
    }
  });

  console.log("\n🔗 Live Explorer Links:");
  console.log(`   ROLA Asset:     https://stellar.expert/explorer/testnet/asset/ROLA-${rolaIssuer.publicKey()}`);
  console.log(`   USDC Asset:     https://stellar.expert/explorer/testnet/asset/USDC-${usdcIssuer.publicKey()}`);
  console.log(`   Swap Tx:        https://stellar.expert/explorer/testnet/tx/${swapResult.hash}`);
}

runBattleTest().catch(console.error);
