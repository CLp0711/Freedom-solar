# Stellar Integration Strategy: Ryowa Labs Solar Model

This document outlines how to implement the `rola` and `shoka` solar tokenomics model natively on the Stellar Network, taking advantage of Stellar's protocol-level features and Soroban smart contracts.

---

## 1. Token Architecture: Stellar Asset Contract (SAC) vs. Soroban Custom Token

We will issue both **`rola`** and **`shoka`** as **Stellar Classic Assets** rather than building custom token smart contracts from scratch. 

```mermaid
graph LR
    Classic[Stellar Classic Asset] -->|Auto-Generated| SAC[Stellar Asset Contract]
    SAC -->|SEP-41 Interface| Soroban[Soroban Smart Contracts]
```

### Why use Stellar Classic Assets + SAC?
*   **Protocol-Level Efficiency**: Transfers, trustlines, and balances are processed directly by the Stellar core ledger, making them faster and cheaper than WASM-based contracts.
*   **Automatic Soroban Interface**: Stellar automatically generates a Soroban contract wrapper (the Stellar Asset Contract, or SAC) for every classic asset, exposing the standard **SEP-41 token interface**.
*   **Native DEX Compatibility**: Classic assets can be traded directly on Stellar's native Decentralized Exchange (DEX) and protocol-level Automated Market Makers (AMMs) without wrapping.

---

## 2. Smart Contract Storage Optimization on Soroban

Soroban uses a unique state archival model divided into three storage types. We will leverage them to keep fees low and handle reward expirations cleanly:

| Storage Type | Lifetime | Best For | Implementation in Ryowa |
| :--- | :--- | :--- | :--- |
| **Instance** | Persistent (Tied to Contract) | Global configuration | Reward rates, Admin keys, Token contract addresses. |
| **Persistent** | Long-term | User-specific vital data | Staked `rola` balances, deposit timestamps. |
| **Temporary** | Short-term | Ephemeral data / logs | Inactive claim trackers, short-term reward tallies. |

### Permanent Asset Guarantees
We use **Persistent** storage for both `rola` stake balances and `shoka` reward claims. This guarantees that user positions and yields never expire or get swept automatically, ensuring long-term asset security for dormant holders. If a user returns after years, they can still restore their archived persistent state and claim their accumulated rewards.

---

## 3. Transaction Fee Sponsorship (Gasless UX)

To make the system accessible to non-crypto native users (e.g., local mobile money or digital wallet holders), we will use **Stellar Fee Sponsorship**.

```mermaid
sequenceDiagram
    participant User as Mobile Wallet / Web App User
    participant Server as Ryowa Backend
    participant Network as Stellar Testnet
    
    User->>Server: Request to claim Shoka reward
    Server->>Server: Sign transaction as Fee Sponsor
    Server->>User: Request user signature for operation
    User->>Server: Return user signature
    Server->>Network: Submit sponsored transaction
    Note over Network: Gas paid in XLM by Ryowa; User pays 0 XLM
```

### Implementation Details:
1.  **Fee Sponsor Account**: Ryowa Labs maintains a funded Stellar account with XLM.
2.  **Sponsorship Operations**: When creating transactions (e.g. staking, claiming rewards), the transaction envelope contains the `BeginSponsoringFutureReserves` and `EndSponsoringFutureReserves` operations.
3.  **User Experience**: The user's wallet (or app-embedded signer) signs the transaction, but pays 0 XLM. The transaction fees are charged to the Ryowa backend.

---

## 4. Native AMM vs. Soroban AMM for `shoka/USDC`

Stellar has a built-in, protocol-level AMM. We will utilize it for the `shoka/USDC` liquidity pool:
*   **No Contract Overhead**: We can create and seed liquidity pools directly using Stellar transaction operations (`ChangeTrust` with LP asset type and `LiquidityPoolDeposit`).
*   **Seamless Swaps**: Soroban contracts can interface directly with native AMM pools or utilize third-party Soroban DEX routers to execute the `USDC` buyback of `shoka`.
