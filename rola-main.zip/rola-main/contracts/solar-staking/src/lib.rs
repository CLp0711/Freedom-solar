#![no_std]
use soroban_sdk::{contract, contractimpl, contracttype, token, Address, Env};

// Define keys for contract storage
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DataKey {
    Admin,
    RolaToken,
    ShokaToken,
    RewardRate,      // SHOKA tokens minted/distributed per ROLA per second
    Staker(Address), // Maps user address to StakerInfo
    TotalStaked,
}

// Struct to track staker information
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StakerInfo {
    pub amount: i128,              // Amount of ROLA tokens staked (Watts of capacity)
    pub last_update: u64,          // Last block timestamp of action (stake/claim/unstake)
    pub accumulated_rewards: i128, // Accumulated but unclaimed SHOKA reward tokens
}

const SECONDS_PER_YEAR: u64 = 31_536_000;

#[contract]
pub struct SolarStaking;

#[contractimpl]
impl SolarStaking {
    /// Initialize the contract with configuration parameters.
    pub fn initialize(
        env: Env,
        admin: Address,
        rola_token: Address,
        shoka_token: Address,
        reward_rate: i128,
    ) {
        if env.storage().instance().has(&DataKey::Admin) {
            panic!("Contract is already initialized");
        }
        env.storage().instance().set(&DataKey::Admin, &admin);
        env.storage().instance().set(&DataKey::RolaToken, &rola_token);
        env.storage().instance().set(&DataKey::ShokaToken, &shoka_token);
        env.storage().instance().set(&DataKey::RewardRate, &reward_rate);
        env.storage().instance().set(&DataKey::TotalStaked, &0i128);
    }

    /// Retrieve the admin address.
    pub fn get_admin(env: Env) -> Address {
        env.storage().instance().get(&DataKey::Admin).unwrap()
    }

    /// Retrieve the reward rate.
    pub fn get_reward_rate(env: Env) -> i128 {
        env.storage().instance().get(&DataKey::RewardRate).unwrap()
    }

    /// Retrieve the total amount of ROLA currently staked.
    pub fn get_total_staked(env: Env) -> i128 {
        env.storage().instance().get(&DataKey::TotalStaked).unwrap_or(0)
    }

    /// Retrieve a staker's information.
    pub fn get_staker(env: Env, user: Address) -> Option<StakerInfo> {
        env.storage().persistent().get(&DataKey::Staker(user))
    }

    /// Calculate the current pending rewards for a staker.
    pub fn get_pending_rewards(env: Env, user: Address) -> i128 {
        let current_time = env.ledger().timestamp();
        let staker_info_opt: Option<StakerInfo> = env.storage().persistent().get(&DataKey::Staker(user.clone()));
        
        match staker_info_opt {
            None => 0,
            Some(staker) => {
                if staker.amount == 0 {
                    staker.accumulated_rewards
                } else {
                    let time_diff = current_time.saturating_sub(staker.last_update);
                    let reward_rate = Self::get_reward_rate(env.clone());
                    
                    // Reward formula: (Staked ROLA * Time in Seconds * Reward Rate) / Seconds in a Year
                    let new_rewards = (staker.amount * (time_diff as i128) * reward_rate) / (SECONDS_PER_YEAR as i128);
                    staker.accumulated_rewards + new_rewards
                }
            }
        }
    }

    /// Stake ROLA tokens into the contract to start farming SHOKA.
    pub fn stake(env: Env, user: Address, amount: i128) {
        user.require_auth();
        if amount <= 0 {
            panic!("Amount must be positive");
        }

        let rola_address: Address = env.storage().instance().get(&DataKey::RolaToken).unwrap();
        let rola_client = token::Client::new(&env, &rola_address);
        
        // Transfer ROLA from the user to this contract
        rola_client.transfer(&user, &env.current_contract_address(), &amount);

        let current_time = env.ledger().timestamp();
        let mut staker = Self::get_staker(env.clone(), user.clone()).unwrap_or(StakerInfo {
            amount: 0,
            last_update: current_time,
            accumulated_rewards: 0,
        });

        // Calculate and roll over rewards before increasing the stake
        if staker.amount > 0 {
            staker.accumulated_rewards = Self::get_pending_rewards(env.clone(), user.clone());
        }
        
        staker.amount += amount;
        staker.last_update = current_time;

        // Save staker state
        env.storage().persistent().set(&DataKey::Staker(user.clone()), &staker);

        // Update total staked
        let mut total_staked = Self::get_total_staked(env.clone());
        total_staked += amount;
        env.storage().instance().set(&DataKey::TotalStaked, &total_staked);
    }

    /// Withdraw staked ROLA tokens from the contract.
    pub fn unstake(env: Env, user: Address, amount: i128) {
        user.require_auth();
        if amount <= 0 {
            panic!("Amount must be positive");
        }

        let mut staker = Self::get_staker(env.clone(), user.clone()).expect("Staker not found");
        if staker.amount < amount {
            panic!("Insufficient staked balance");
        }

        let current_time = env.ledger().timestamp();
        
        // Calculate pending rewards before updating staked amount
        staker.accumulated_rewards = Self::get_pending_rewards(env.clone(), user.clone());
        staker.amount -= amount;
        staker.last_update = current_time;

        // Save staker state
        env.storage().persistent().set(&DataKey::Staker(user.clone()), &staker);

        // Update total staked
        let mut total_staked = Self::get_total_staked(env.clone());
        total_staked -= amount;
        env.storage().instance().set(&DataKey::TotalStaked, &total_staked);

        // Transfer ROLA back to the user
        let rola_address: Address = env.storage().instance().get(&DataKey::RolaToken).unwrap();
        let rola_client = token::Client::new(&env, &rola_address);
        rola_client.transfer(&env.current_contract_address(), &user, &amount);
    }

    /// Claim accrued SHOKA reward tokens.
    pub fn claim(env: Env, user: Address) {
        user.require_auth();
        
        let mut staker = Self::get_staker(env.clone(), user.clone()).expect("Staker not found");
        let reward_to_claim = Self::get_pending_rewards(env.clone(), user.clone());
        
        if reward_to_claim <= 0 {
            panic!("No rewards to claim");
        }

        let current_time = env.ledger().timestamp();
        staker.accumulated_rewards = 0;
        staker.last_update = current_time;

        // Save staker state
        env.storage().persistent().set(&DataKey::Staker(user.clone()), &staker);

        // Transfer SHOKA reward tokens to the user
        let shoka_address: Address = env.storage().instance().get(&DataKey::ShokaToken).unwrap();
        let shoka_client = token::Client::new(&env, &shoka_address);
        shoka_client.transfer(&env.current_contract_address(), &user, &reward_to_claim);
    }
}

#[cfg(test)]
mod test;
