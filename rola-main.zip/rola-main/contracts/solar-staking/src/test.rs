use super::*;
use soroban_sdk::{
    contract, contractimpl, testutils::Ledger, testutils::Address as _, Address, Env,
};

// Custom Mock Token for Staking and Rewards
#[contract]
pub struct MockToken;

#[contractimpl]
impl MockToken {
    pub fn mint(env: Env, to: Address, amount: i128) {
        let mut balance: i128 = env.storage().persistent().get(&to).unwrap_or(0);
        balance += amount;
        env.storage().persistent().set(&to, &balance);
    }

    pub fn balance(env: Env, id: Address) -> i128 {
        env.storage().persistent().get(&id).unwrap_or(0)
    }

    pub fn transfer(env: Env, from: Address, to: Address, amount: i128) {
        from.require_auth();
        let mut from_balance: i128 = env.storage().persistent().get(&from).unwrap_or(0);
        let mut to_balance: i128 = env.storage().persistent().get(&to).unwrap_or(0);
        if from_balance < amount {
            panic!("insufficient balance");
        }
        from_balance -= amount;
        to_balance += amount;
        env.storage().persistent().set(&from, &from_balance);
        env.storage().persistent().set(&to, &to_balance);
    }

    pub fn transfer_from(env: Env, spender: Address, from: Address, to: Address, amount: i128) {
        spender.require_auth();
        let mut from_balance: i128 = env.storage().persistent().get(&from).unwrap_or(0);
        let mut to_balance: i128 = env.storage().persistent().get(&to).unwrap_or(0);
        if from_balance < amount {
            panic!("insufficient balance");
        }
        from_balance -= amount;
        to_balance += amount;
        env.storage().persistent().set(&from, &from_balance);
        env.storage().persistent().set(&to, &to_balance);
    }

    pub fn approve(_env: Env, _from: Address, _spender: Address, _amount: i128) {}
    pub fn allowance(_env: Env, _from: Address, _spender: Address) -> i128 { 0 }
}

#[test]
fn test_staking_flow() {
    let env = Env::default();
    env.mock_all_auths();

    // 1. Generate Addresses (using the testutils::Address trait)
    let admin = Address::generate(&env);
    let user = Address::generate(&env);

    // 2. Register Mock Tokens
    let rola_id = env.register(MockToken, ());
    let shoka_id = env.register(MockToken, ());

    // Create MockToken Clients to allow calling mint() in tests
    let rola_client = MockTokenClient::new(&env, &rola_id);
    let shoka_client = MockTokenClient::new(&env, &shoka_id);

    // 3. Register and Initialize Solar Staking Contract
    let staking_id = env.register(SolarStaking, ());
    let staking_client = SolarStakingClient::new(&env, &staking_id);

    // Reward rate: 100,000 SHOKA tokens per year
    let reward_rate_per_year: i128 = 100_000; 
    
    staking_client.initialize(
        &admin,
        &rola_id,
        &shoka_id,
        &reward_rate_per_year,
    );

    // Check basic parameters
    assert_eq!(staking_client.get_admin(), admin);
    assert_eq!(staking_client.get_reward_rate(), reward_rate_per_year);
    assert_eq!(staking_client.get_total_staked(), 0);

    // 4. Setup Initial Balances
    // Mint 1000 ROLA to user
    rola_client.mint(&user, &1000);
    assert_eq!(rola_client.balance(&user), 1000);

    // Mint 1,000,000,000 SHOKA rewards pool to Staking Contract
    shoka_client.mint(&staking_id, &1000000000);
    assert_eq!(shoka_client.balance(&staking_id), 1000000000);

    // 5. Stake 500 ROLA
    staking_client.stake(&user, &500);
    
    // Assert ROLA was transferred to the contract
    assert_eq!(rola_client.balance(&user), 500);
    assert_eq!(rola_client.balance(&staking_id), 500);
    assert_eq!(staking_client.get_total_staked(), 500);

    // 6. Fast Forward Time (1 year = 31,536,000 seconds)
    let start_time = env.ledger().timestamp();
    env.ledger().set_timestamp(start_time + SECONDS_PER_YEAR);

    // Pending rewards: 500 (staked) * 100,000 (rate) = 50,000,000
    let pending = staking_client.get_pending_rewards(&user);
    assert_eq!(pending, 50_000_000);

    // 7. Claim Rewards
    staking_client.claim(&user);
    
    // User should have received 50,000,000 SHOKA tokens
    assert_eq!(shoka_client.balance(&user), 50_000_000);
    assert_eq!(staking_client.get_pending_rewards(&user), 0);

    // 8. Test Indefinite Reward Accumulation (No Expiry)
    // Stake remains, wait 1.5 years (SECONDS_PER_YEAR * 3 / 2) without user action
    env.ledger().set_timestamp(env.ledger().timestamp() + (SECONDS_PER_YEAR * 3 / 2));
    
    // User accrued rewards for 1.5 years: 500 * 100,000 * 1.5 = 75,000,000
    let pending_accumulated = staking_client.get_pending_rewards(&user);
    assert_eq!(pending_accumulated, 75_000_000);

    // Verify user can successfully claim the entire accumulated reward
    let user_shoka_before = shoka_client.balance(&user);
    staking_client.claim(&user);
    
    // User should have received the extra 75,000,000 SHOKA
    assert_eq!(shoka_client.balance(&user), user_shoka_before + 75_000_000);
    assert_eq!(staking_client.get_pending_rewards(&user), 0);

    // 9. Unstake ROLA
    staking_client.unstake(&user, &500);
    assert_eq!(rola_client.balance(&user), 1000);
    assert_eq!(staking_client.get_total_staked(), 0);
}
