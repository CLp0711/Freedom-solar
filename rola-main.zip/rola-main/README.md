# ☀️ ROLA: Solar Micro-Asset Protocol (Stellar Testnet & Soroban)

[![Stellar Network](https://img.shields.io/badge/Stellar-Testnet-blue.svg?style=flat-square)](https://stellar.org)
[![Soroban SDK](https://img.shields.io/badge/Soroban-v27.0.1-orange.svg?style=flat-square)](https://soroban.stellar.org)
[![Whitepaper](https://img.shields.io/badge/Whitepaper-PDF-red.svg?style=flat-square)](https://github.com/Ryowa-labs/Rola-whitepaper/blob/main/whitepaper.pdf)
[![License](https://img.shields.io/badge/License-Apache%202.0-green.svg?style=flat-square)](https://opensource.org/licenses/Apache-2.0)

This repository contains the complete smart contract architecture, testnet deployment scripts, and local ledger verification suites for [ROLA](https://github.com/Ryowa-labs/Rola-whitepaper/blob/main/whitepaper.pdf), the foundational Real-World Asset (RWA) tokenization protocol by **Ryowa Labs**.

[ROLA](https://github.com/Ryowa-labs/Rola-whitepaper/blob/main/whitepaper.pdf) fractionalizes commercial solar installations into micro-assets representing physical capacity under signed Power Purchase Agreements (PPAs).

---

## 📂 Repository Structure

*   **[contracts/](file:///home/kimani/Umoroto/stellar/ryowa-labs/contracts/)**: Contains the Soroban smart contracts in Rust (e.g. `solar-staking` for yield farming).
*   **[gateway/](file:///home/kimani/Umoroto/stellar/ryowa-labs/gateway/)**: Contains the JavaScript SDK scripts used to issue, mint, and verify the `ROLA` token on the Stellar ledger via localized payment API templates.
*   **Design Blueprints**: Detailed documentation on [DESIGN.md](file:///home/kimani/Umoroto/stellar/ryowa-labs/DESIGN.md), [TOKENOMICS.md](file:///home/kimani/Umoroto/stellar/ryowa-labs/TOKENOMICS.md), and [STELLAR_INTEGRATION.md](file:///home/kimani/Umoroto/stellar/ryowa-labs/STELLAR_INTEGRATION.md).

---

## ☀️ The Concept: Fractionalizing Solar PPAs

*   **Democratic Access**: Rather than requiring high upfront capital investments, ROLA fractionalizes solar installations into accessible increments.
*   **The Unit**: **1 ROLA Token = 1 Watt of Solar Capacity**.
*   **Capacity Example**: This deployment represents a **55kW (55,000 Watts)** commercial solar installation, resulting in a fixed supply of **55,000 ROLA** tokens issued.
*   **Passive Farming**: Holding ROLA qualifies users to mine/farm **SHOKA** (the Ryowa ecosystem utility token), which is continuously backed by real-world energy bill payments collected via local fiat payment gateways (e.g., M-Pesa, Pix, UPI, or card payments) and swapped into USDC.

```mermaid
graph TD
    PPA[Solar PPA Signed] -->|Mint 1 Token per Watt| Rola[rola Token]
    Rola -->|Staked/Held| Farm[Soroban Staking Contract]
    Farm -->|Mints Yield| Shoka[shoka Token]
    
    Offtaker[PPA Local Fiat Payments] -->|Convert to USDC| Treasury[Ryowa Treasury]
    Treasury -->|Inject USDC Buyback| AMM[shoka / USDC AMM Pool]
```

---

## 🚀 Native Stellar & Soroban Architecture

Instead of writing a custom ERC-20 token contract in WASM, ROLA is issued as a **Stellar Classic Asset** and automatically wrapped into a **Stellar Asset Contract (SAC)**:

1.  **Stellar Core Execution**: Transfers, trustlines, and balances run at the ledger level, avoiding expensive gas/compute costs.
2.  **Stellar Asset Contract (SAC) wrapper**: Stellar automatically generates a Soroban-compatible wrapper for the asset, implementing the standardized **SEP-41** token contract interface.
3.  **Soroban Contract ID**: Any Soroban smart contract can interact with ROLA using its deterministic contract address:
    `CAZDQ34M7PMXAHU2XME3ANIQTZJ76MUIS572WZSM4XXCYWOSF2VIHQIB`

---

## ⛓️ Testnet Deployment Details

The asset was successfully issued and verified on the **Stellar Testnet**.

| Parameter | Value / Live Explorer Link |
| :--- | :--- |
| **Asset Code** | `ROLA` |
| **Total Supply** | `55,000.0000000 ROLA` (55kW Capacity) |
| **Issuer Account** | [`GAOSAG76RTPXEWJM2OZSVFTQRAL4AY5DGM56GX2HKLOBV2AVU3FWGMJS`](https://stellar.expert/explorer/testnet/account/GAOSAG76RTPXEWJM2OZSVFTQRAL4AY5DGM56GX2HKLOBV2AVU3FWGMJS) |
| **Distributor Account** | [`GAKOWWKXKZEYRC4SHX7IFHLMVPEXLXTSTN4LCQH5MGRDPAKMQPQQUIZS`](https://stellar.expert/explorer/testnet/account/GAKOWWKXKZEYRC4SHX7IFHLMVPEXLXTSTN4LCQH5MGRDPAKMQPQQUIZS) |
| **Stellar Asset Contract (SAC) ID** | `CAZDQ34M7PMXAHU2XME3ANIQTZJ76MUIS572WZSM4XXCYWOSF2VIHQIB` |
| **Trustline Transaction Hash** | [`3cd07676a...`](https://stellar.expert/explorer/testnet/tx/3cd07676a0ef6fefce345936c24d52f40cbb1f3de63d7f672b59d5de587b6c4b) |
| **Minting Transaction Hash** | [`c27e09b09...`](https://stellar.expert/explorer/testnet/tx/c27e09b096568d1710e9d5b73ec6d4b9ce7cde567872d0787cf040a7e216618d) |

---

## 🛠️ Verification & Testing

### 1. Run Live Ledger Verification Tests
Query the Horizon testnet ledger to assert trustlines, balances, and contract wrapping details:
```bash
cd gateway
npm install
npm test
```

### 2. Run the AMM Battle Test (Simulate USDC Buyback Loop)
Simulate the core tokenomics loop live on the testnet by creating assets, seeding a liquidity pool (AMM), and performing a swap:
```bash
cd gateway
node battle_test_amm.js
```

**Test Cases Verified:**
*   [x] Verify that the **Issuer Account** exists and is funded.
*   [x] Verify that the **Distributor Account** exists and is funded.
*   [x] Verify that the **ROLA trustline** is active on the distributor.
*   [x] Verify that the **ROLA balance** matches exactly `55,000` (representing the 55kW PPA capacity).
*   [x] Verify that the **Soroban SAC Wrapper ID** matches the deterministic derivation.

### 2. Test the Soroban Rust Smart Contract (Yield Calculation Logic)
Navigate to the root directory and run the Rust unit tests:
```bash
cargo test
```

**Logic Verified:**
*   [x] Staking contract initialization and storage settings.
*   [x] User ROLA staking and transfer validation.
*   [x] SHOKA reward interest calculation per second.
*   [x] User reward claiming and balance safety.
*   [x] Unstaking ROLA principal withdrawal.

---

## 💻 Interfacing with ROLA in Soroban (Rust)

To accept, stake, or transfer ROLA within a Soroban smart contract, use the `soroban-sdk::token` client:

```rust
use soroban_sdk::{contract, contractimpl, Address, Env};

#[contract]
pub struct SolarStakingContract;

#[contractimpl]
impl SolarStakingContract {
    pub fn stake_rola(env: Env, user: Address, amount: i128) {
        // SAC Contract ID for ROLA
        let rola_contract_address = Address::from_string(
            &env, 
            "CAZDQ34M7PMXAHU2XME3ANIQTZJ76MUIS572WZSM4XXCYWOSF2VIHQIB"
        );
        
        // Initialize SEP-41 Client
        let rola_client = soroban_sdk::token::Client::new(&env, &rola_contract_address);
        
        // Transfer ROLA from investor to this contract for staking
        rola_client.transfer(&user, &env.current_contract_address(), &amount);
    }
}
```
