# Ryowa Labs: Dual-Token Solar RWA Tokenomics (`rola` & `shoka`)

This document details the economic loop, minting mechanics, and AMM integration for the dual-token solar PPA ecosystem.

---

## 1. The Dual-Token Concept

Instead of a single yield token, we split the ecosystem into a physical asset token and a liquid reward token.

```mermaid
graph TD
    PPA[Solar PPA Signed] -->|Mint 1 Token per Watt| Rola[rola Token]
    Rola -->|Stakes or Holds| Farm[Farming Contract]
    Farm -->|Mints Reward| Shoka[shoka Token]
    
    Offtaker[PPA Local Fiat Payments] -->|Convert to USDC| Treasury[Ryowa Treasury]
    Treasury -->|Inject USDC to Buyback / LP| AMM[shoka / USDC AMM Pool]
```

### A. The `rola` Token (The Solar Asset Token)
*   **Purpose**: Represents fractionalized ownership of physical solar capacity.
*   **Minting Rule**: Minted **only** when a physical PPA is signed and installed.
*   **Denomination**: 1 token = 1 watt. 
    *   *Example*: A 55 kW ($55,000 \text{ watts}$) solar contract mints exactly $55,000$ `rola` tokens.
*   **Access**: Allows retail investors to buy very small fractional shares (e.g., 10 watts for $10 USD) and earn yield.

### B. The `shoka` Token (The Reward/Ecosystem Token)
*   **Purpose**: The liquid reward token distributed to `rola` holders.
*   **Minting Rule**: Minted over time as mining/farming rewards based on solar production or time.
*   **Liquidity**: Paired against USDC on a Stellar AMM (Liquidity Pool).

---

## 2. The Economic Loop & AMM Pricing

To prevent `shoka` from losing value, it is backed by the real USDC cash flow generated from solar paybills:

1.  **Revenue Collection**: Ryowa Labs collects power bills from solar clients via localized payment gateways and APIs (e.g., M-Pesa, Pix, UPI, cards, or bank transfers).
2.  **USDC Conversion**: The local currency revenue is converted to USDC.
3.  **Buy-and-Make / AMM Support**: Ryowa Labs deposits the USDC into the `shoka/USDC` AMM.
    *   *Buybacks*: The treasury uses USDC to buy `shoka` from the pool, driving the price of `shoka` up.
    *   *Protocol-Owned Liquidity (POL)*: The treasury pairs USDC with `shoka` to deepen the liquidity pool. The trading fees generated belong to Ryowa Labs.

---

## 3. Persistent Staking and Reward Claims (Indefinite Accumulation)

To foster maximum investor trust, Ryowa Labs establishes a highly user-friendly yield model:

*   **No Expiry or Wiping**: Accrued `shoka` rewards never expire or get swept back. Even if an investor goes dormant for years, their accumulated yield remains fully claimable at any time.
*   **Asset Persistence**: Staked `rola` capacity and earned `shoka` balances belong to the user permanently. This aligns with traditional equity models (like stock dividends) and builds deep institutional credibility.

---

## 4. Why This Architecture is Excellent for Business

1.  **Zero Upfront Capital Cost for Rewards**: You mint `shoka` utility tokens for free to reward holders. The actual yield value is injected afterward via real solar USDC revenue.
2.  **Captures Inactive Capital**: Unclaimed `shoka` rewards are recycled directly into your treasury, strengthening your liquidity depth.
3.  **Fractional Inclusion**: By tying `rola` to watts, someone with just pocket change in any local currency (e.g., KES, BRL, INR, or USD cents) can buy 1 watt of a solar installation and start farming `shoka`.
